#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
#include"decode.h"


int main(int argc, char *argv[])/* Main function for encoding/decoding based on user input */
{
   DecodeInfo decInfo;// Structure to hold decoding information
   int op_type = check_operation_type(argv[1]);// Check operation type based on the first argument
   //step1:Check op_type equal to e_encode or not
   if(op_type == e_encode)
   {
      printf("*Encoding is started*\n");// Indicate that encoding has started
    EncodeInfo encInfo;// Structure to hold encoding information
    if(read_and_validate_encode_args(argv,&encInfo)==e_failure)// Validate encoding arguments
    {
        printf("Read and validation failed\n");// Print error if validation fails
        return 0;
    }
    else{
        do_encoding(&encInfo);// Proceed with encoding
    }
    //Step2: Yes ->Print encoding started, No -> step3
  

    return e_success;
   }
    //Step3: Check op_type is equal to e_decode or not
    
   else if(op_type == e_decode)
   {
      //step4:Yes ->Print decoding Started, No ->step5
    printf("*Decoding is started\n");
    if(read_and_validate_decode_args(argv,&decInfo)==e_failure)// Validate decoding arguments
    {
        printf("Read and Validation is failed\n");// Print error if validation fails
        return 0;
    }
    else{
        do_decoding(&decInfo);// Proceed with decoding
    }
   }
   else{
    //Srep5: Print the error message and return e_failure
    printf("Error Invalid input\n");// Indicate invalid input
    return 0;
   }
   
   

}
OperationType check_operation_type(char *arg)/* Function to check the operation type based on the command-line argument */
{
    //step 1: Check arg is -e or not
if(strcmp(arg,"-e")==0)
{
    return e_encode; //Step 2: Yes -> return e_encode, No -> Goto step3
}
else if(strcmp(arg,"-d")==0)//Step 3: Check arg ios -d or not 
{
    return e_decode;//step 4: Yes -> return e_decode,No -> Goto step 5
}
else{
    return e_unsupported; //Step 5: return e_unsupported
}
}
