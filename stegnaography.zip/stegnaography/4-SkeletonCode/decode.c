#include <stdio.h>
#include<string.h>
#include "common.h"
#include "decode.h"
#include "types.h"
/* Function to read and validate command-line arguments for decoding */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if(argv[2]!=NULL)// Check if the source image filename is provided
    {
        if(strstr(argv[2],".bmp"))// Validate the BMP file extension
        {
            decInfo->src_image_fname=argv[2];// Store the source image filename
        }
         else
        {
            printf("Error: stegoimage not exist\n");
            return e_failure;// Return failure if the file is not a BMP
        }
    }
    if(argv[3]!=NULL)// Check if the decode filename is provided
    {
        decInfo->decode_fname=argv[3];// Store the decode filename
        //printf("%s\n",decInfo->decode_fname);
    }
    else
    {
        decInfo->decode_fname="decode";// Default filename if not provided
       // printf("%s\n",decInfo->decode_fname);
    }
    return e_success;// Return success
}
Status decode_open_files(DecodeInfo *decInfo)/* Function to open source image file for decoding */
{
     // Src Image file
    decInfo->fptr_src_image=fopen(decInfo->src_image_fname,"r");// Open the source image file
    // Do Error handling
    if (decInfo->fptr_src_image == NULL)// Error handling for file opening
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->src_image_fname);
        return e_failure;// Return failure if unable to open the file
    }
    return e_success;
}
Status decode_get_lsb(char * arr)/* Function to decode the least significant bit */
{
    *arr=(*arr)&1;// Extract the least significant bit
    return e_success;// Return success

}
Status decode_magic_string(FILE* fptr_src_image)/* Function to decode the magic string from the image */
{
    char ch=0;// Initialize character for magic string
    int size=strlen(MAGIC_STRING);// Get size of the magic string
    char magic_string[size+1];// Array to hold the decoded magic string
    char data[8];// Buffer for reading data
    fseek(fptr_src_image,54L,SEEK_SET);// Seek to start of image data
    for(int i=0;i<size;i++)
    {
        ch=0;// Reset character for each byte
        fread(&data,1,8,fptr_src_image);// Read 8 bits from the image
        for(int j=0;j<8;j++)
        {
        decode_get_lsb(&data[j]);// Get the LSB
        ch=(data[j]<<j)|ch;// Construct the character from LSBs
        }
        magic_string[i]=ch;// Store the character in the magic string

    }
    magic_string[size]='\0';// Null terminate the magic string
  //  printf("magic string is: %s\n",magic_string);
    if(strcmp(magic_string, MAGIC_STRING)==0)
    {
        return e_success;// Return success if matched
    }
    else
    {
        return e_failure;// Return failure if not matched
    }
}
Status decode_secret_file_extn(DecodeInfo *decInfo, int size, FILE *fptr_src_image)/* Function to decode the secret file extension from the image */
{
    char arr[8],ch,seceret_file_extn[size];// Buffer for reading and storing extension
   // printf("%d\n",size);
    for(int i=0;i<size;i++)
    {

        fread(&arr,1,8,fptr_src_image);// Read 8 bits for each character
        for(int j=0;j<8;j++)
        {
            decode_get_lsb(&arr[j]);// Get the LSB
            ch=(arr[j]<<j)|ch;// Construct the character
        }
        seceret_file_extn[i]=ch;// Store the character in extension array
        ch=0;// Reset character for the next byte
    }
    seceret_file_extn[size]='\0';// Null terminate the extension string
    //printf("exten is %s\n",seceret_file_extn);
    strcpy(decInfo->decode_file_name,decInfo->decode_fname);
    strcat(decInfo->decode_file_name,seceret_file_extn);
    //printf("decode file name is %s\n",decInfo->decode_file_name);
    decInfo->fptr_decode_file=fopen(decInfo->decode_file_name,"w");// Open the decode file for writing
    if(decInfo->fptr_decode_file==NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> decode_file_name);
        return e_failure;
    }
    return e_success;
}
int extn_size=0;// Global variable for the extension size
Status decode_secret_file_extn_size(DecodeInfo *decInfo,FILE *fptr_src_image)/* Function to decode the size of the secret file extension */
{
    char arr[32];// Buffer for reading 32 bits
   fread(&arr,1,32,fptr_src_image);// Read 32 bits for extension size
    for(int i=0;i<32;i++)
    {
        decode_get_lsb(&arr[i]);// Get the LSB
        extn_size = (((int)arr[i]) << i)|extn_size;// Construct the extension size
    }
    //printf("exten size: %d\n",extn_size);
    return e_success;
}
/* Function to decode the size of the secret file */
Status decode_secret_file_size(DecodeInfo *decInfo, FILE *fptr_src_image)
{
    char arr1[32];// Buffer for reading 32 bits
    int size_sec_file=0;// Initialize secret file size
    fread(&arr1,1,32,fptr_src_image);// Read 32 bits for secret file size
    for(int i=0;i<32;i++)
    {
        decode_get_lsb(&arr1[i]);// Get the LSB
        size_sec_file=(((int)arr1[i])<<i)| size_sec_file;// Construct the secret file size
    }
    decInfo->secret_file_size=size_sec_file;// Store the size in decode info
   // printf("size of secret file %d\n",decInfo->secret_file_size);
    return e_success;
}
/* Function to decode the secret data into the output file */
Status decode_secret_data(DecodeInfo *decInfo, FILE *fptr_src_image, FILE *fptr_decode_file)
{
    
    char arr[8], data = 0;// Buffer for reading data
    for(int i=0;i < decInfo->secret_file_size;i++)
    {
        fread(&arr,1, 8,decInfo ->fptr_src_image);
        for(int j=0; j <8; j++)
        {
            decode_get_lsb(&arr[j]);// Read 8 bits
            data=(arr[j] << j)|data;// Construct the character
        }
        fwrite(&data, 1, 1, decInfo -> fptr_decode_file);// Write the character to decode file
        data=0;// Reset data for the next byte
    }
    return e_success;
}
Status do_decoding(DecodeInfo *decInfo)
{
    if(decode_open_files(decInfo)==e_success)
    {
        printf("All the files are opened successfully\n");
        if(decode_magic_string(decInfo->fptr_src_image)==e_success)
        {
            printf("magic string is decoded\n");
            if(decode_secret_file_extn_size(decInfo,decInfo->fptr_src_image)==e_success)
            {
                printf("seceret file extension size is decoded success fully\n");
                if(decode_secret_file_extn(decInfo, extn_size,decInfo->fptr_src_image)==e_success)
                {
                    printf("Secret file extension is decoded successfully\n");
                    if(decode_secret_file_size(decInfo,decInfo->fptr_src_image)==e_success)
                    {
                        printf("sceret file size is decoded\n");
                        if(decode_secret_data(decInfo,decInfo->fptr_src_image,decInfo->fptr_decode_file)==e_success)
                        {
                            printf("secert data is decoded successfully\n");
                            return e_success;
                        }
                        else
                        {
                            printf("seceret data is not encoded \n");
                        }
                    }

                    else
                    {
                        printf("sceret file size is not  decoded\n");
                        e_failure;
                    }
                }
                else
                {
                    printf("Secret file extension is not decode\n");
                }
            }
            else
            {
                printf("seceret file extension size is  not decoded \n");
                return e_failure;
            }
        }
        else
        {
            printf("magic string is not decoded\n");
            return e_failure;
        }
    }
    else
    {
        printf("files are not opened\n");
        e_failure;
    }
}
