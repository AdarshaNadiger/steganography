#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include<string.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
   // printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
   // printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3; //pixels into bytes
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
        
    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    /*step1: argv[2] is .bmp file or not
      step2:if yes->store argv[2] to structure member goto step 3,
      no->print error message return e_failure
      step3:checl argv[3] is .txt or not
      step4:if yes->store argv[3] to structure member goto step 5,
      no->print error message return e_failure
      step5:check argv[4] passed or not
      step6:if passed->step 7, if not passed store default name to structure mumber
      step7:check .bmp file or not
      step8:yes->store into structure member, no->print error message,return e_failure*/

    /* Check each command-line argument for the correct file extensions */
    if(argv[2]==NULL)
    {
        printf("Insufficient argument\n");
        return e_failure;
    }
    if(strstr(argv[2],".bmp"))
    {
        encInfo->src_image_fname=argv[2];// Store source image filename
        printf("%s\n",encInfo->src_image_fname);
        
    }   
    else
    {
        printf("Insufficient argument\n");
        return e_failure;
    }
    
    if(argv[3]==NULL)
    {
        printf("Insufficient argument\n");
        return e_failure;
    }

    if(strstr(argv[3],".txt"))
    {
    
        encInfo->secret_fname=argv[3];// Store secret filename
        printf("%s\n",encInfo->secret_fname);
        
    }
    else
    {
    
        printf("Insufficient argument\n");
        return e_failure;
    }
    
    if(argv[4]==NULL)
    {
        encInfo->stego_image_fname="stego.bmp";// Default filename
        printf("%s\n",encInfo->stego_image_fname);
    }
    else
    {
        if(strstr(argv[4],".bmp"))
        {
            encInfo->stego_image_fname=argv[4];// Store stego filename
            printf("%s\n",encInfo->stego_image_fname);
        }
        else
        {
            printf("Insufficient argument\n");
            return e_failure;
        }
    }

    return e_success;
}
int extn_file_size=0;// Size of the extension of the secret file
int secret_file_size;// Size of the secret file
uint src_file_size;// Size of the source file
/* Check if the source image can accommodate the secret data */
Status check_capacity(EncodeInfo *encInfo)
{
    /*step1:Find the source file size,secret file size and
    extn. file size*/
    src_file_size=get_image_size_for_bmp(encInfo->fptr_src_image);
   printf("source file size %d\n",src_file_size);
   encInfo->image_capacity=src_file_size;// Set image capacity
   fseek(encInfo->fptr_secret,0,SEEK_END);// Seek to end of secret file
   secret_file_size=ftell(encInfo->fptr_secret); // Get size of secret file
   //rewind(encInfo->fptr_secret);
   printf("secrete file size is %d\n",secret_file_size);
   encInfo->size_secret_file=secret_file_size;// Store size of secret file
   int count=0;// Get the extension of the secret file
   char extn_file[10];
   int i;
   for(i=0;encInfo->secret_fname[i]!='.';i++);// Find the position of '.'
   for(int j=i;encInfo->secret_fname[j]!='\0';j++)
   {
        extn_file_size++;// Count the size of the extension
        extn_file[count++]=encInfo->secret_fname[j];
   }
    extn_file[count]='\0';// Null terminate the extension string
   printf("extension name: %s\n",extn_file);
   printf("extn. file size is %d\n",extn_file_size);
   strcpy(encInfo->extn_secret_file,extn_file);// Store the extension
    //step2:comparision ->true return e_success, false->e_failure
    // Compare available capacity with required capacity
    if(src_file_size>(54+(((strlen(MAGIC_STRING))+4+secret_file_size+4+extn_file_size)*8)))
    {
        printf("source file having a sufficient size for encoding\n");
        return e_success;// Capacity is sufficient
    }
    else
    {
        printf("ERROR: source file not having a sufficient size for encoding\n");
        return e_failure;// Capacity is insufficient
    }

}
/* Copy the BMP header from the source to the destination image */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char header[54];// BMP header size is 54 bytes
    fseek(fptr_src_image,0,SEEK_SET);// Seek to start of source file
    fread(header,54,1,fptr_src_image);// Read header from source
    fwrite(header,54,1,fptr_dest_image);// Write header to destination
    return e_success;
}

Status encode_byte_to_lsb(char *arr, char ch)/* Encode a byte into the least significant bit of an array */
{
    //step1:clear a bit in the arr[0]
    //step2:get a bit from ch
    //step3:replace the get bit int to arr[0]th lsb position
    //step4:repeat the operation 8 times
    for(int i=0;i<8;i++)
    {
        arr[i]=arr[i]&(~1);// Clear the LSB
        char temp=ch&(1<<i);// Get the ith bit of ch
        temp=(unsigned)temp>>i;// Shift it to the right position
        arr[i]=arr[i]|temp;// Set the LSB
    }
    return e_success;
}

/* Encode the data into the image using LSB technique */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    /*step1:Read 8 bytes of data from src file and store into arr
    step2:call encode_byte_to_lsb(arr,data[0])*/
    //step3:write a byte of data to dest. file
    //step4:repeat the operation data_length time
    char arr[8];
    for(int i=0;i<size;i++)
    {
        fread(arr,8,1,fptr_src_image);// Read 8 bytes from source
        encode_byte_to_lsb(arr,data[i]);// Encode the data byte
        fwrite(arr,8,1,fptr_stego_image);// Write modified bytes to stego image
    }

return e_success;

    }
    

/* Encode the magic string into the image */
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    //step1:call encode_data_to_image(magic_string,fptr_src_image,fptr_stegno_image)/
    int size=strlen(magic_string);
    printf("magic size %d",size);
    encode_data_to_image(magic_string,size,encInfo->fptr_src_image,encInfo->fptr_stego_image);
    return e_success;
} 
Status encode_size_to_lsb(char *arr,int size)
{
    //clear a bit in arr[0]
    //get a bit from size
    //replace get bit into arr[0]th lsb position
    //repeat the operation 32 times
    for(int i=0;i<32;i++)
    {
        arr[i]=arr[i]&(~1);// Clear the LSB
        char temp=size&(1<<i);// Get the ith bit of size
        temp=(unsigned)temp>>i;// Shift it to the right position
        arr[i]=arr[i]|temp;// Set the LSB
    }
    return e_success;

}
Status encode_secret_file_size(int extn_size,EncodeInfo *encInfo)
{
    char arr[32];
    
    //step1:read 32 bytes from source file and store into array
    //step2:call encode_size_to_lsb(array,extn_size)
    fread(arr,32,1,encInfo->fptr_src_image);// Read 32 bytes from source file into the array
    encode_size_to_lsb(arr,extn_size);// Encode the extension size into the array
    fwrite(arr,32,1,encInfo->fptr_stego_image);// Write modified bytes to stego image
    return e_success;
}
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)/* Encode the secret file extension into the image */
{
    //srep1:call encoding_data_to_image(file_extn,size,encInfo);
    //step2:return e_success
    int size=strlen(file_extn);// Get the size of the file extension
    encode_data_to_image(file_extn,size,encInfo->fptr_src_image,encInfo->fptr_stego_image);
    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)/* Encode the actual secret file data into the image */
{
    //step1:read secret data and store in an array
    //step2:call encode_data_to_image(arr,/file pointers)
    //step3:return e_success
    char arr[secret_file_size];// Array to hold the secret data
    fseek(encInfo->fptr_secret,0,SEEK_SET);// Seek to start of secret file
    fread(arr,secret_file_size,1,encInfo->fptr_secret);// Read secret data into array
    encode_data_to_image(arr,secret_file_size,encInfo->fptr_src_image,encInfo->fptr_stego_image);// Encode data
    //fwrite(arr,secret_file_size,1,encInfo->fptr_stego_image);
    return e_success;
}
Status copy_remaining_img_data(EncodeInfo *encInfo)/* Copy the remaining image data from source to stego image */
{
    int index=ftell(encInfo->fptr_src_image);// Get current position in source file
    printf("source file %d\n",index);
    char ch;
    while(fread(&ch,1,1,encInfo->fptr_src_image)>0)// Read each byte from the source and write to the stego image
    {
        fwrite(&ch,1,1,encInfo->fptr_stego_image);
    }
    index=ftell(encInfo->fptr_src_image);// Get final position in source file
    printf("source file %d\n",index);
    
    return e_success;
}
Status do_encoding(EncodeInfo *encInfo)
{
    //step1:call open file function
    /*step2:check return success or failure 
    step3: if it is
    e_success goto to next step if it is e_failure print
    error message & return e_failure
    step4:call check capcity structure address
    5:cheack return e_success or e_failure 
    step 6:if e_success goto next step else return e_failure
    step7:copy BMP header
    step 8:check return e_success or failure
    step9:e_success print msg goto step10, e_failure->print error
    msg return e_failure
    step10:call magic encode_magic_string(MAGIC_STRING,encInfo->fptr_src_image,encInfo->fptr_stigno_image)*/
    //step11:check return e_success or e_failure
    //step12:e_success print msg, goto step 13 else print error msg and return e_failure
    //step13:call encode_secrete_file_extn_size(extn_size,encInfo->fptr_src_image,)
    //step14:check return e_success or e_failure
    //step15:e_success print msg, goto step 16 else print error msg and return e_failure
    //step16:call encode_secret_file_extn(extn,/file pointers/)
    //step17:check return e_success or e_failure
    //step18:e_success print msg, goto step 19 else print error msg and return e_failure
    //step19:call encode_secrete_file_size(secrete_file_size,encInfo->fptr_src_image,)
    //step20:check return e_success or e_failure
    //step21:e_success print msg, goto step 22 else print error msg and return e_failure
    //step22:call encode_secret_data(encInfo)
    //step23:check return e_success or e_failure
    //step24:e_success print msg, goto step 25 else print error msg and return e_failure
    //step25:call copy_remaining_imag_data(src_file_pointer,dst_file_pointer);
    //step26:check return e_success or e_failure
    //step 27:e_sucess print msg,goto step 28 else print error msg and return e_failure

    if(open_files(encInfo)==e_failure)
    {
        printf("ERROR: Files are not containing data...\n");
        return e_failure;
    }
    else
    {
        printf("All files are opened successfully...\n");
        if(check_capacity(encInfo)==e_success)
        {
            printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
            if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image)==e_success)
            {
                printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                printf("Header file of src copied successfully...\n");
                if(encode_magic_string(MAGIC_STRING,encInfo)==e_success)
                {
                    printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                    printf("\nEncode the magic string successfully...\n");
                    if(encode_secret_file_size(extn_file_size,encInfo)==e_success)
                    {
                        printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                        printf("Encode the secret extension size successfully...\n");
                        if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo)==e_success)
                        {
                            printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                            printf("Encode the secret file extension successfully...\n");
                            if(encode_secret_file_size(secret_file_size,encInfo)==e_success)
                            {
                                printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                                printf("Encode the secret file size successfully...\n");
                                if(encode_secret_file_data(encInfo)==e_success)// Encode the actual secret data
                                {
                                    printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                                    printf("Encode secret data seccessfully...\n");
                                    if(copy_remaining_img_data(encInfo)==e_success)
                                    {
                                        printf("Src image = %ld\nDest image = %ld\n", ftell(encInfo -> fptr_src_image),ftell(encInfo -> fptr_stego_image) );
                                        printf("copied the all remaining data successfilly...\n");
                                        return e_success;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                printf("ERROR: Headerfile of bmp copying is failed\n");
            }
        }
        else
        {
            return e_failure;// Return if capacity check fails
        }
    }
    
}
/*Status read_and_validate_decode_args(char *argv[],EncodeInfo *encInfo)
{
   
}
Status do_decoding(EncodeInfo *encInfo)
{
       
        
    
}*/
