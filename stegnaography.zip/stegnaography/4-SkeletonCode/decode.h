#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types
/*

 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /* stego Image info */
    char *src_image_fname;  //source image file name
    FILE *fptr_src_image;  //file pointer for source image

    /* decode File Info */
    char *decode_fname;     //dest file name(source)
    FILE *fptr_decode_file;      //file pointer for dst file name
    char decode_file_name[20];
    uint secret_file_size;

} DecodeInfo;

/*  Decoding function prototypes */
/* Read and validate Encode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

//opening the files
Status decode_open_files(DecodeInfo *decInfo);

/* Store Magic String */
Status decode_magic_string(FILE* fptr_src_image);

//to get lsb from source image
Status decode_get_lsb(char *arr);

Status decode_secret_file_extn_size(DecodeInfo *decInfo,FILE *fptr_src_image);

Status decode_secret_file_extn(DecodeInfo *decInfo, int size, FILE *fptr_src_image);

Status decode_secret_file_size(DecodeInfo *decInfo, FILE *fptr_src_image);

//Status decode_secret_data(DecodeInfo decInfo, FILE *fptr_src_image,FILE *fptr_decode_file);
Status decode_secret_data(DecodeInfo *decInfo, FILE *fptr_src_image, FILE *fptr_decode_file);
#endif
